'use client'

import { useState } from 'react'
import { X } from 'lucide-react'
import type { LanguageType, ThemeType, PageType } from '@/lib/types'

interface ExpandedMenus {
  settings: boolean
  theme: boolean
  language: boolean
  account: boolean
}

interface SidebarProps {
  isOpen: boolean
  onClose: () => void
  lang: LanguageType
  theme: ThemeType
  onLangChange: (lang: LanguageType) => void
  onThemeChange: (theme: ThemeType) => void
  onNavigate: (page: PageType) => void
}

const content = {
  ar: {
    home: 'صفحة Platec الرئيسية',
    images: 'الصور',
    cards: 'البطاقات',
    backgrounds: 'الخلفيات',
    language: 'اللغة',
    settings: 'الإعدادات',
    theme: 'المظهر',
    light: 'المظهر الفاتح',
    dark: 'المظهر الداكن',
    arabic: 'اللغة العربية',
    english: 'اللغة الانجليزية',
  },
  en: {
    home: 'Platec Home Page',
    images: 'Images',
    cards: 'Cards',
    backgrounds: 'Backgrounds',
    language: 'Language',
    settings: 'Settings',
    theme: 'Theme',
    light: 'Light Mode',
    dark: 'Dark Mode',
    arabic: 'Arabic',
    english: 'English',
  },
}

export function Sidebar({
  isOpen,
  onClose,
  lang,
  theme,
  onLangChange,
  onThemeChange,
  onNavigate,
}: SidebarProps) {
  const [expandedMenus, setExpandedMenus] = useState<ExpandedMenus>({
    settings: false,
    theme: false,
    language: false,
    account: false,
  })

  const t = content[lang]
  const isRTL = lang === 'ar'

  const toggleMenu = (menuKey: keyof ExpandedMenus) => {
    setExpandedMenus((prev) => ({ ...prev, [menuKey]: !prev[menuKey] }))
  }

  const handleNavigateHome = () => {
    onNavigate('home')
    onClose()
  }

  return (
    <>
      <aside
        className={`fixed top-0 z-50 h-full w-[75%] md:w-[350px] bg-white dark:bg-gray-950 shadow-2xl transition-transform duration-300 ${
          isOpen
            ? 'translate-x-0'
            : isRTL
              ? 'translate-x-full'
              : '-translate-x-full'
        } ${isRTL ? 'right-0' : 'left-0'} flex flex-col`}
      >
        <div className="h-[150px] bg-black text-white relative shrink-0">
          <button
            onClick={onClose}
            className={`absolute top-4 ${isRTL ? 'left-6' : 'right-6'} hover:text-red-500 transition-colors`}
            aria-label="إغلاق القائمة"
          >
            <X size={28} />
          </button>
          <h2
            onClick={handleNavigateHome}
            className={`absolute bottom-6 ${isRTL ? 'right-6' : 'left-6'} text-3xl font-black cursor-pointer uppercase`}
          >
            Platec
          </h2>
        </div>

        <div className="flex-1 overflow-y-auto pt-4 flex flex-col px-6 gap-1">
          <button
            onClick={handleNavigateHome}
            className="text-right py-3 font-bold hover:text-yellow-500 transition-colors"
          >
            {t.home}
          </button>
          <button className="text-right py-3 font-bold hover:text-yellow-500 transition-colors">
            {t.images}
          </button>
          <button className="text-right py-3 font-bold hover:text-yellow-500 transition-colors">
            {t.cards}
          </button>
          <button className="text-right py-3 font-bold hover:text-yellow-500 transition-colors">
            {t.backgrounds}
          </button>

          <div className="h-px bg-gray-100 dark:bg-gray-800 my-4" />

          {/* Language Toggle */}
          <button
            onClick={() => toggleMenu('language')}
            className="w-full flex justify-between items-center py-3 font-bold text-sm"
          >
            <span>{t.language}</span>
            <span
              className={`transition-transform ${expandedMenus.language ? 'rotate-90' : ''}`}
            >
              ‹
            </span>
          </button>
          {expandedMenus.language && (
            <div className="bg-gray-50 dark:bg-gray-900/50 rounded-lg p-2 space-y-2">
              <button
                onClick={() => onLangChange('ar')}
                className={`w-full text-right p-2 text-xs font-bold ${lang === 'ar' ? 'text-yellow-600' : ''}`}
              >
                {t.arabic}
              </button>
              <button
                onClick={() => onLangChange('en')}
                className={`w-full text-right p-2 text-xs font-bold ${lang === 'en' ? 'text-yellow-600' : ''}`}
              >
                {t.english}
              </button>
            </div>
          )}

          {/* Settings & Theme */}
          <button
            onClick={() => toggleMenu('settings')}
            className="w-full flex justify-between items-center py-3 font-bold text-sm"
          >
            <span>{t.settings}</span>
            <span
              className={`transition-transform ${expandedMenus.settings ? 'rotate-90' : ''}`}
            >
              ‹
            </span>
          </button>
          {expandedMenus.settings && (
            <div className="bg-gray-50 dark:bg-gray-900/50 rounded-lg p-2 space-y-2">
              <button
                onClick={() => toggleMenu('theme')}
                className="w-full flex justify-between items-center p-2 text-xs font-bold border-b border-gray-100 dark:border-gray-800"
              >
                <span>{t.theme}</span>
                <span>{theme === 'light' ? t.light : t.dark}</span>
              </button>
              {expandedMenus.theme && (
                <div className="flex gap-2 p-2">
                  <button
                    onClick={() => onThemeChange('light')}
                    className={`flex-1 p-2 text-[10px] border rounded ${theme === 'light' ? 'bg-black text-white' : ''}`}
                  >
                    {t.light}
                  </button>
                  <button
                    onClick={() => onThemeChange('dark')}
                    className={`flex-1 p-2 text-[10px] border rounded ${theme === 'dark' ? 'bg-black text-white' : ''}`}
                  >
                    {t.dark}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
        <div className="p-6 border-t border-gray-100 dark:border-gray-900">
          <h3 className="text-black dark:text-white text-lg font-black tracking-[0.2em] italic text-center">
            PLATEC
          </h3>
        </div>
      </aside>
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 backdrop-blur-sm"
          onClick={onClose}
        />
      )}
    </>
  )
}
