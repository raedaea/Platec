'use client'

import type { LanguageType, PageType } from '@/lib/types'

interface TermsPageProps {
  lang: LanguageType
  onNavigate: (page: PageType) => void
}

const content = {
  ar: {
    back: 'العودة للرئيسية',
  },
  en: {
    back: 'Back to Home',
  },
}

export function TermsPage({ lang, onNavigate }: TermsPageProps) {
  const t = content[lang]

  const handleBack = () => {
    onNavigate('home')
    window.scrollTo(0, 0)
  }

  return (
    <div className="max-w-4xl mx-auto py-12 px-6 animate-fade-in text-gray-800 dark:text-gray-200 leading-relaxed">
      <h2 className="text-3xl font-black mb-8 border-b-2 border-yellow-500 pb-2 inline-block">
        اتفاقية شروط الاستخدام
      </h2>
      <div className="space-y-8">
        <section>
          <h3 className="text-xl font-black mb-3 underline decoration-yellow-500">
            1. الملكية الفكرية
          </h3>
          <p>المنتجات الرقمية هي ملكية فكرية حصرية لموقع Platec.</p>
        </section>
        <section>
          <h3 className="text-xl font-black mb-3 underline decoration-yellow-500">
            2. شروط الاستخدام
          </h3>
          <p>
            يُسمح باستخدام المنتجات للأغراض الشخصية والتجارية وفقاً للترخيص
            المحدد.
          </p>
        </section>
        <section>
          <h3 className="text-xl font-black mb-3 underline decoration-yellow-500">
            3. سياسة الإرجاع
          </h3>
          <p>
            نظراً لطبيعة المنتجات الرقمية، لا يمكن إرجاع المنتجات بعد التحميل.
          </p>
        </section>
        <section>
          <h3 className="text-xl font-black mb-3 underline decoration-yellow-500">
            4. التعديلات
          </h3>
          <p>
            نحتفظ بالحق في تعديل هذه الشروط في أي وقت دون إشعار مسبق.
          </p>
        </section>
      </div>
      <button
        onClick={handleBack}
        className="mt-12 w-full py-4 bg-black text-white font-black rounded-xl hover:bg-yellow-600 transition-colors"
      >
        {t.back}
      </button>
    </div>
  )
}
