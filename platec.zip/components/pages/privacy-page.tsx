'use client'

import type { LanguageType, PageType } from '@/lib/types'

interface PrivacyPageProps {
  lang: LanguageType
  onNavigate: (page: PageType) => void
}

const content = {
  ar: {
    back: 'العودة للرئيسية',
  },
  en: {
    back: 'Back to Home',
  },
}

export function PrivacyPage({ lang, onNavigate }: PrivacyPageProps) {
  const t = content[lang]

  const handleBack = () => {
    onNavigate('home')
    window.scrollTo(0, 0)
  }

  return (
    <div className="max-w-4xl mx-auto py-12 px-6 animate-fade-in text-gray-800 dark:text-gray-200 leading-relaxed">
      <h2 className="text-3xl font-black mb-8 border-b-2 border-yellow-500 pb-2 inline-block">
        سياسة الخصوصية
      </h2>
      <div className="space-y-8">
        <p className="font-bold text-lg">
          أهلا بك في موقعنا. نحن نقدر ثقتك في اختيار تصاميمنا، ونلتزم بحماية
          خصوصيتك وبياناتك الشخصية.
        </p>
        <section>
          <h3 className="text-xl font-black mb-3 underline decoration-yellow-500">
            1. المعلومات التي نجمعها
          </h3>
          <p className="mb-2">
            نقوم بجمع معلومات الاتصال، بيانات الدفع، والمعلومات التقنية.
          </p>
        </section>
        <section>
          <h3 className="text-xl font-black mb-3 underline decoration-yellow-500">
            2. كيفية استخدام المعلومات
          </h3>
          <p className="mb-2">
            نستخدم معلوماتك لمعالجة الطلبات وتحسين خدماتنا والتواصل معك.
          </p>
        </section>
        <section>
          <h3 className="text-xl font-black mb-3 underline decoration-yellow-500">
            3. حماية البيانات
          </h3>
          <p className="mb-2">
            نستخدم تقنيات أمان متقدمة لحماية بياناتك الشخصية.
          </p>
        </section>
        <section>
          <h3 className="text-xl font-black mb-3 underline decoration-yellow-500">
            4. حقوقك
          </h3>
          <p className="mb-2">
            يحق لك الوصول إلى بياناتك وتصحيحها أو حذفها في أي وقت.
          </p>
        </section>
      </div>
      <button
        onClick={handleBack}
        className="mt-12 w-full py-4 bg-black text-white font-black rounded-xl hover:bg-yellow-600 transition-colors"
      >
        {t.back}
      </button>
    </div>
  )
}
