'use client'

import { Menu, User, ShoppingCart, Search } from 'lucide-react'

interface HeaderProps {
  onMenuOpen: () => void
  onNavigateHome: () => void
}

export function Header({ onMenuOpen, onNavigateHome }: HeaderProps) {
  return (
    <header className="h-[60px] w-full bg-gray-900 text-white flex items-center px-4 fixed top-0 z-40 shadow-lg">
      <div className="flex items-center gap-1 flex-1 justify-start">
        <button
          onClick={onMenuOpen}
          className="p-2 hover:bg-white/10 rounded-full transition-colors"
          aria-label="فتح القائمة"
        >
          <Menu size={24} />
        </button>
        <button
          className="p-2 hover:bg-white/10 rounded-full transition-colors"
          aria-label="الحساب"
        >
          <User size={24} />
        </button>
      </div>
      <h1
        onClick={onNavigateHome}
        className="text-[24px] cursor-pointer font-black tracking-tighter absolute left-1/2 -translate-x-1/2 whitespace-nowrap uppercase"
      >
        PLATEC
      </h1>
      <div className="flex items-center gap-1 flex-1 justify-end">
        <button
          className="p-2 hover:bg-white/10 rounded-full transition-colors"
          aria-label="البحث"
        >
          <Search size={24} />
        </button>
        <button
          className="p-2 hover:bg-white/10 rounded-full transition-colors relative"
          aria-label="عربة التسوق"
        >
          <ShoppingCart size={24} />
        </button>
      </div>
    </header>
  )
}
