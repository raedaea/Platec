'use client'

import type { LanguageType, PageType } from '@/lib/types'

interface FooterProps {
  lang: LanguageType
  onNavigate: (page: PageType) => void
}

const content = {
  ar: {
    home: 'صفحة Platec الرئيسية',
    terms: 'شروط الاستخدام',
    privacy: 'سياسة الخصوصية',
    customerService: 'خدمة العملاء',
    copyrightText: 'جميع الحقوق محفوظة © 2026 Platec',
  },
  en: {
    home: 'Platec Home Page',
    terms: 'Terms of Use',
    privacy: 'Privacy Policy',
    customerService: 'Customer Service',
    copyrightText: 'All Rights Reserved © 2026 Platec',
  },
}

export function Footer({ lang, onNavigate }: FooterProps) {
  const t = content[lang]

  return (
    <footer className="w-full bg-black text-white h-[150px] py-6 mt-auto px-6 border-t border-gray-800 flex flex-col justify-center">
      <div className="max-w-7xl mx-auto w-full flex flex-col items-center gap-4 text-center">
        <div className="grid grid-cols-2 w-full text-sm font-bold max-w-sm">
          <div className="flex flex-col gap-3">
            <button
              onClick={() => onNavigate('home')}
              className="hover:text-yellow-500 transition-colors"
            >
              {t.home}
            </button>
            <button
              onClick={() => onNavigate('terms')}
              className="hover:text-yellow-500 transition-colors"
            >
              {t.terms}
            </button>
          </div>
          <div className="flex flex-col gap-3">
            <button className="hover:text-yellow-500 transition-colors">
              {t.customerService}
            </button>
            <button
              onClick={() => onNavigate('privacy')}
              className="hover:text-yellow-500 transition-colors"
            >
              {t.privacy}
            </button>
          </div>
        </div>
        <p className="text-gray-600 text-[11px] font-bold tracking-wide mt-2 uppercase">
          {t.copyrightText}
        </p>
      </div>
    </footer>
  )
}
