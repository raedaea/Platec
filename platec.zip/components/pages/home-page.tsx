'use client'

import { Palette } from 'lucide-react'
import type { LanguageType } from '@/lib/types'

interface HomePageProps {
  lang: LanguageType
}

const content = {
  ar: {
    images: 'الصور',
    cards: 'البطاقات',
    backgrounds: 'الخلفيات',
  },
  en: {
    images: 'Images',
    cards: 'Cards',
    backgrounds: 'Backgrounds',
  },
}

export function HomePage({ lang }: HomePageProps) {
  const t = content[lang]

  const homeSections = [
    { id: 'images', title: t.images },
    { id: 'backgrounds', title: t.backgrounds },
    { id: 'cards', title: t.cards },
  ]

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 space-y-12">
      {homeSections.map((section) => (
        <section key={section.id} className="animate-fade-in">
          <div className="flex items-center gap-3 mb-6 border-b-2 border-yellow-500 pb-2 w-fit">
            <Palette size={24} className="text-yellow-500" />
            <h2 className="text-2xl font-black uppercase tracking-tight dark:text-white">
              {section.title}
            </h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {[1, 2, 3, 4].map((item) => (
              <div
                key={item}
                className="group relative aspect-square bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl flex flex-col items-center justify-center shadow-sm hover:shadow-xl hover:scale-[1.02] transition-all cursor-pointer overflow-hidden"
              >
                <Palette
                  size={48}
                  className="text-gray-200 dark:text-gray-800 group-hover:text-yellow-500/20 transition-colors"
                />
                <div className="absolute bottom-4 text-[10px] font-black uppercase tracking-widest text-gray-400">
                  {section.id} #{item}
                </div>
              </div>
            ))}
          </div>
        </section>
      ))}
    </div>
  )
}
