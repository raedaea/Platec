"use client"
import { createContext, useContext, useState, useEffect } from "react"
import type React from "react"

type Language = "ar" | "en"
type Theme = "light" | "dark"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  theme: Theme
  setTheme: (theme: Theme) => void
  translations: Record<string, string>
}

const translations = {
  ar: {
    home: "صفحة BestPlatec الرئيسية",
    images: "الصور",
    videos: "الفيديو",
    files: "الملفات",
    games: "الألعاب",
    language: "اللغة",
    settings: "الإعدادات",
    account: "الحساب",
    theme: "المظهر",
    search: "البحث",
    termsOfUse: "شروط الاستخدام",
    privacyPolicy: "سياسة الخصوصية",
  },
  en: {
    home: "BestPlatec Home",
    images: "Images",
    videos: "Videos",
    files: "Files",
    games: "Games",
    language: "Language",
    settings: "Settings",
    account: "Account",
    theme: "Theme",
    search: "Search",
    termsOfUse: "Terms of Use",
    privacyPolicy: "Privacy Policy",
  },
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("ar")
  const [theme, setTheme] = useState<Theme>("light")

  useEffect(() => {
    // Update document direction and language
    document.documentElement.lang = language
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr"
  }, [language])

  useEffect(() => {
    // Update theme
    if (theme === "dark") {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [theme])

  const value = {
    language,
    setLanguage,
    theme,
    setTheme,
    translations: translations[language],
  }

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
