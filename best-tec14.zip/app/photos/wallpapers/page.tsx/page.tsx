"use client"

import { useLanguage } from "@/contexts/LanguageContext"
import { useRouter } from "next/navigation"
import { useEffect, useRef, useState } from "react"
import { Search, X, Download, ArrowRight, ArrowLeft, Play, Pause } from "lucide-react"

function SocialCard({ isArabic }: { isArabic: boolean }) {
  const [showDropdown, setShowDropdown] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  const dropdownItems = isArabic
    ? ["الأحدث", "الأقدم", "حجم الأعلى", "حجم الأقل", "الأحرف أ - ي", "إعادة الضبط"]
    : ["Newest", "Oldest", "Size High", "Size Low", "Letters A-Z", "Reset"]

  const items = isArabic ? ["يوتيوب", "انستقرام", "مشاركة", "فرز"] : ["YouTube", "Instagram", "Share", "Sort"]

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setShowDropdown(false)
      }
    }
    if (showDropdown) document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [showDropdown])

  return (
    <div
      className="relative flex items-center border border-black rounded-lg shadow-md overflow-visible mt-[100px]"
      style={{ width: "clamp(303px, 70%, 450px)", height: "clamp(50px, 8vw, 75px)" }}
    >
      {items.map((label, index) => (
        <div
          key={index}
          className="flex items-center justify-center border-l border-black last:border-none"
          style={{ width: "clamp(75px, 20%, 100px)", height: "100%" }}
        >
          {label !== "فرز" && label !== "Sort" ? (
            <span className="flex items-center justify-center h-full" style={{ fontSize: "clamp(10px, 1.2vw, 12px)" }}>
              {label}
            </span>
          ) : (
            <div className="relative flex items-center justify-center w-full h-full" ref={dropdownRef}>
              <button
                className="flex items-center justify-center h-full w-full"
                style={{ fontSize: "clamp(10px, 1.2vw, 12px)" }}
                onClick={() => setShowDropdown(!showDropdown)}
              >
                {label}
              </button>
              {showDropdown && (
                <div
                  className="absolute top-full mt-1 bg-white border border-gray-300 shadow-lg rounded-md overflow-hidden z-20"
                  style={{ width: "clamp(75px, 20%, 100px)" }}
                >
                  {dropdownItems.map((f, i) => (
                    <button
                      key={i}
                      className="w-full h-[25px] flex items-center justify-center text-gray-800 hover:bg-gray-100 border-b last:border-b-0"
                      style={{ fontSize: "clamp(10px, 1vw, 12px)" }}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

function SearchBar({ search, setSearch, isArabic }: { search: string; setSearch: (value: string) => void; isArabic: boolean }) {
  const [windowWidth, setWindowWidth] = useState(0)

  useEffect(() => {
    const updateWidth = () => setWindowWidth(window.innerWidth)
    updateWidth()
    window.addEventListener('resize', updateWidth)
    return () => window.removeEventListener('resize', updateWidth)
  }, [])

  const xSize = windowWidth >= 768 ? 20 : 14
  const fontSize = windowWidth >= 768 ? "24px" : "16px"
  const iconWidth = windowWidth >= 768 ? 65 : 50
  const searchIconSize = windowWidth >= 768 ? 26 : 24
  const barHeight = windowWidth >= 768 ? 65 : 50
  const paddingStart = `${iconWidth + 10}px`
  const paddingEnd = windowWidth >= 768 ? "45px" : "35px"
  const xPosition = 10

  return (
    <div className="flex flex-col items-center gap-3 mb-6">
      <div
        className="relative border-2 border-gray-300 bg-white rounded-[10px] overflow-hidden w-[320px] sm:w-[400px] md:w-[500px]"
        style={{ height: `${barHeight}px`, display: "flex", alignItems: "center" }}
      >
        {/* أيقونة البحث */}
        <div
          className="flex items-center justify-center bg-yellow-400 absolute top-0 h-full"
          style={{ width: `${iconWidth}px`, [isArabic ? "right" : "left"]: 0 }}
        >
          <Search className="text-black" style={{ width: `${searchIconSize}px`, height: `${searchIconSize}px` }} />
        </div>

        {/* حقل البحث */}
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={isArabic ? "ابحث عن ملفات صوتية..." : "Search audio files..."}
          className="w-full bg-transparent outline-none"
          style={{
            fontSize,
            height: `${barHeight}px`,
            lineHeight: `${barHeight}px`,
            paddingInlineStart: paddingStart,
            paddingInlineEnd: paddingEnd,
            textAlign: isArabic ? "right" : "left",
            boxSizing: "border-box",
          }}
        />

        {/* زر × لمسح البحث */}
        {search && (
          <button
            onClick={() => setSearch("")}
            className="absolute top-1/2 transform -translate-y-1/2 flex items-center justify-center text-black hover:text-black bg-gray-200 rounded-full"
            style={{
              width: `clamp(18px, 2.5vw, 28px)`,
              height: `clamp(18px, 2.5vw, 28px)`,
              [isArabic ? "left" : "right"]: `${xPosition}px`
            }}
          >
            <X style={{ width: `${xSize}px`, height: `${xSize}px` }} />
          </button>
        )}
      </div>
    </div>
  )
}

function AudioCard({ isArabic }: { isArabic: boolean }) {
  const [isPlaying, setIsPlaying] = useState(false)
  const fontSize = typeof window !== "undefined" && window.innerWidth >= 768 ? "26px" : "20px"

  return (
    <div className="relative rounded-xl p-[3px] bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 shadow-lg">
      <div
        className="rounded-xl bg-white flex items-center justify-between px-4"
        style={{ height: "clamp(50px,8vw,75px)", width: "clamp(200px,70%,500px)" }}
      >
        <div className="flex items-center gap-3 h-full">
          <button onClick={() => setIsPlaying(!isPlaying)} className="text-blue-600 hover:text-blue-800 flex items-center justify-center h-full">
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
          </button>
          <span className="flex items-center h-full" style={{ fontSize }}>
            {isArabic ? "ملف صوتي 1" : "Audio File 1"}
          </span>
        </div>
        <button className="text-blue-600 hover:text-blue-800 flex items-center justify-center h-full">
          <Download className="w-4 h-4" />
        </button>
      </div>
    </div>
  )
}

export default function AudioFilesPage() {
  const { language } = useLanguage()
  const isArabic = language === "ar"
  const router = useRouter()
  const [search, setSearch] = useState("")

  return (
    <div dir={isArabic ? "rtl" : "ltr"} className="min-h-screen bg-white px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => router.back()}
          className="flex items-center gap-2 text-gray-600 hover:text-black transition-colors"
        >
          {isArabic ? <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" /> : <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />}
          <span>{isArabic ? "العودة" : "Back"}</span>
        </button>
        <h1 style={{ fontSize: "clamp(18px, 2vw, 24px)" }} className="font-bold">
          {isArabic ? "الملفات الصوتية" : "Audio Files"}
        </h1>
        <div className="w-16 sm:w-20"></div>
      </div>

      <SearchBar search={search} setSearch={setSearch} isArabic={isArabic} />

      <div className="flex justify-center">
        <SocialCard isArabic={isArabic} />
      </div>

      <div className="grid grid-cols-1 gap-4 mt-[50px]">
        <AudioCard isArabic={isArabic} />
      </div>
    </div>
  )
}
