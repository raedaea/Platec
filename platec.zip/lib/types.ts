export type PageType = 'home' | 'privacy' | 'terms'
export type LanguageType = 'ar' | 'en'
export type ThemeType = 'light' | 'dark'
