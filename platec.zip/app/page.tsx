'use client'

import { useState, useEffect } from 'react'
import type { PageType, LanguageType, ThemeType } from '@/lib/types'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { Sidebar } from '@/components/layout/sidebar'
import { HomePage } from '@/components/pages/home-page'
import { PrivacyPage } from '@/components/pages/privacy-page'
import { TermsPage } from '@/components/pages/terms-page'

export default function Page() {
  const [currentPage, setCurrentPage] = useState<PageType>('home')
  const [lang, setLang] = useState<LanguageType>('ar')
  const [theme, setTheme] = useState<ThemeType>('light')
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const isRTL = lang === 'ar'

  // إدارة التنسيقات والوضع الداكن
  useEffect(() => {
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr'
    document.documentElement.lang = lang
    if (theme === 'dark') {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [lang, theme, isRTL])

  const handleNavigate = (page: PageType) => {
    setCurrentPage(page)
  }

  const handleNavigateHome = () => {
    setCurrentPage('home')
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex flex-col font-sans transition-colors duration-300">
      <Header
        onMenuOpen={() => setIsMenuOpen(true)}
        onNavigateHome={handleNavigateHome}
      />

      <main className="pt-[60px] flex-grow">
        {currentPage === 'home' && <HomePage lang={lang} />}
        {currentPage === 'privacy' && (
          <PrivacyPage lang={lang} onNavigate={handleNavigate} />
        )}
        {currentPage === 'terms' && (
          <TermsPage lang={lang} onNavigate={handleNavigate} />
        )}
      </main>

      <Footer lang={lang} onNavigate={handleNavigate} />

      <Sidebar
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        lang={lang}
        theme={theme}
        onLangChange={setLang}
        onThemeChange={setTheme}
        onNavigate={handleNavigate}
      />
    </div>
  )
}
